# -*- coding: cp1251 -*-
from selenium import webdriver
import time
from bs4 import BeautifulSoup
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import re

class web:

    def __init__(self, link):
        options = webdriver.ChromeOptions()
        options.add_argument('headless')
        self.browser = webdriver.Chrome(options=options)
        self.msg = MIMEMultipart()
        self.link = link
        self.connection(link)

    def close_connection(self):
        self.browser.close()

    def get_html_text(self):
        return self.browser.page_source

    def connection(self, link):
        self.browser.get(link)
        time.sleep(1)
        return self.browser.page_source

    def __del__(self):
        self.close_connection()

def get_content(html):
    news = []
    if html.link == 'https://smev3.gosuslugi.ru/portal':
        #print(html.get_html_text())
        soup = BeautifulSoup(html.get_html_text(),"lxml")
        html.browser.find_element_by_xpath('// *[ @ id = "grayblock_1162"] / div / p[1] / span / a').click()
        time.sleep(1)
        items = soup.find_all("div", {"class": "info-section gray-container"})
        for item in items:
            item_tmp = item
            color_check1 = item_tmp.find("span", style = 'color:#FF0000')
            color_check2 = item_tmp.find("span", style='color:rgb(255, 0, 0)')
            if (color_check1 != None or color_check2 != None):
                tmps = item.find_all('h2') + item.find_all('h3') + item.find_all('p') + item.find_all('h4')
                news.append(tmps)
        return news
    if html.link == 'https://smev3.gosuslugi.ru/portal/news.jsp':
        i = 3
        while True:
            xpath = '//*[@id="news_0"]/ul/li[i]/a'
            xpath = xpath.replace('[i]', '[' + str(i) + ']')
            try:
                html.browser.find_element_by_xpath(xpath).click()
                soup = BeautifulSoup(html.get_html_text(), "lxml")
                items = soup.find_all("div", {"class": "panel panel-news"})
                for item in items:
                    item = re.sub(r'href="#collapse....."', '',str(item))
                    item = re.sub(r'<h3>', '<h2>', str(item))
                    item = re.sub(r'<a class="collapsed" data-parent="#accordion" data-toggle="collapse" >', '<span style="color:#FF0000" class="collapsed" data-parent="#accordion" data-toggle="collapse" >', str(item))
                    item = re.sub(r'</a></h2>', '</span></h2>', str(item))
                    news.append(item)
            except BaseException:
                break
            i+=1
            time.sleep(1)
        return news

def send_email(news):
    email = 'tt3st1n@yandex.ru'
    password = 'testmail1'

    server = smtplib.SMTP('smtp.yandex.ru', 587)
    server.ehlo()
    server.starttls()
    server.login(email, password)

    from_addr = 'tt3st1n@yandex.ru'
    toaddr = 'dima_pesotskiy@mail.ru'
    msg_body = '<html> <body>'
    for i in range (0, len(news)):
        msg_body = str(msg_body) + ''.join(map(str,news[i]))
    msg_body = str(msg_body) + '</body></html>'

    """
    msg_body_new = ''
    msg_body_new = msg_body_new.join(map(str,msg_body))
    print(str(msg_body_new))
    """

    msg = MIMEText(str(msg_body), 'html', 'utf-8')
    msg['Subject'] = '��� ������ �� ��������� �������'
    msg['From'] = from_addr
    msg['To'] = toaddr

    server.set_debuglevel(1)
    server.sendmail(email, toaddr, msg.as_string())
    server.quit()

def newparser():
    html = web('https://smev3.gosuslugi.ru/portal')
    smev3_news = get_content(html)
    del html
    time.sleep(1)
    html_1 = web('https://smev3.gosuslugi.ru/portal/news.jsp')
    next_smev3_news = get_content(html_1)
    del html_1
    #for new in smev3_news:
       #print(new)
    send_email(smev3_news + next_smev3_news)
    input("������� Enter ��� ������")

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    newparser()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
